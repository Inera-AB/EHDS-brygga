# Hem - SE EHDS Brygga Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Hem**

## Hem

| | |
| :--- | :--- |
| *Official URL*:https://fhir.inera.se/ImplementationGuide/se.ehds.brygga | *Version*:0.1.0 |
| Draft as of 2026-06-24 | *Computable Name*:SEEHDSBrygga |

# SE EHDS Brygga – Implementation Guide

## Vad är EHDS-bryggan?

EHDS-bryggan är en tjänst som möjliggör åtkomst till svenska hälsodata via FHIR R4 API, i enlighet med kraven i EU:s förordning om det europeiska hälsodatautrymmet (EHDS – European Health Data Space).

Bryggan fungerar som ett översättningslager mellan:

* **FHIR R4** – det moderna, öppna API-protokoll som EHDS kräver för primär och sekundär användning av hälsodata
* **Ineras RIVTA-tjänstekontrakt** – de etablerade SOAP/XML-baserade nationella tjänstekontrakten som svenska journalsystem och vårdinformationssystem redan implementerar

Genom EHDS-bryggan kan FHIR-klienter hämta patientdata från nationella källor utan att källsystemen behöver bygga om sina befintliga integrationer.

## Syfte med denna Implementation Guide

Denna Implementation Guide (IG) dokumenterar och definierar de FHIR-profiler och mappningar som EHDS-bryggan använder. Den riktar sig till:

* Systemutvecklare som integrerar mot EHDS-bryggan via FHIR
* Arkitekter som utvärderar EHDS-bryggan för sin organisation
* Informatiker och kliniker som vill förstå hur svenska hälsodata representeras i FHIR

## Tjänstekontrakt och mappningar

EHDS-bryggan mappar Ineras RIVTA-tjänstekontrakt till FHIR R4-resurser. Mappningarna är konfigurationsdrivna och nya tjänstekontrakt kan läggas till utan kodändringar i bryggan.

### Implementerade mappningar

| | | |
| :--- | :--- | :--- |
| `GetDiagnosis:2` | [Condition](StructureDefinition-se-ehds-condition.md) | Implementerad |
| `GetDocumentList:1` | [DocumentReference](StructureDefinition-se-ehds-document-reference.md) | Implementerad |

### Planerade mappningar

| | | |
| :--- | :--- | :--- |
| `GetMedication:2` | MedicationStatement | Planerad |
| `GetObservation:1` | Observation | Planerad |
| `GetAllergyIntolerance:1` | AllergyIntolerance | Planerad |

## Dokumentation

* [Mappning: GetDiagnosis → Condition](mapping-getdiagnosis.md) – Detaljerad mappningstabell och exempel
* [Mappning: GetDocumentList → DocumentReference](mapping-getdocumentlist.md) – Fältmappning och OID-konverteringar
* [Arkitektur](architecture.md) – Systembeskrivning och flödesdiagram
* [OID-till-URI-mappningar](naming-systems.md) – Alla 12 OID↔URI-konverteringar som NamingSystem-resurser
* [Artefakter](artifacts.md) – Alla FHIR-profiler, kodsystem och valuemängder
* [Nedladdningar](downloads.md) – FHIR NPM-paket (`package.tgz`)

## Teknisk information

* **FHIR-version:** R4 (4.0.1)
* **Canonical URL:** `https://fhir.inera.se/ig/EHDS-brygga`
* **Utgivare:** Inera AB
* **Kontakt:** ehds@inera.se
* **Status:** Draft (ci-build)

